package modelo;

public enum TipoEvento {
    IO,
    MUTEX_SOLICITACAO,
    MUTEX_LIBERACAO
}