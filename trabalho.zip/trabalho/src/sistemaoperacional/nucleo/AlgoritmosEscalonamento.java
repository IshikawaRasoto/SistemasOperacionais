package sistemaoperacional.nucleo;

public enum AlgoritmosEscalonamento {
    FIFO,
    SRTF,
    PRIORIDADE_PREEMPTIVO,
    PRIORIDADE_PREEMPTIVO_ENVELHECIMENTO
}