package sistemaoperacional.nucleo;

public enum CausaEscalonamento {
    QUANTUM_EXPIRADO,
    NOVA_TAREFA,
    TAREFA_FINALIZADA,
    CPU_OCIOSA,
    ENVELHECIMENTO
}