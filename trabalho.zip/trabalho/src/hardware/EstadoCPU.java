package hardware;

public enum EstadoCPU {
    OCUPADA,
    OCIOSA;
}
